﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Assignment4_ana;

public class Game1 : Game
{
    private GraphicsDeviceManager _graphics;
    private SpriteBatch _spriteBatch;
    private Starfish star1;
    private Starfish star2;
    private Texture2D starfishy;
    private Texture2D coral;

    public Game1()
    {
        _graphics = new GraphicsDeviceManager(this);
        Content.RootDirectory = "Content";
        IsMouseVisible = true;
    }

    protected override void Initialize()
    {
        // TODO: Add your initialization logic here
        
        base.Initialize();
    }

    protected override void LoadContent()
    {
        _spriteBatch = new SpriteBatch(GraphicsDevice);
        starfishy = Content.Load<Texture2D>("imgs/estrellita");
        coral = Content.Load<Texture2D>("imgs/estrellita");
        
        // first star
        star1 = new Starfish(coral, starfishy, new Vector2(200, 200f));
        
        //second star
        star2 = new Starfish(coral, starfishy, new Vector2(100, 100f));

        // TODO: use this.Content to load your game content here
    }

    protected override void Update(GameTime gameTime)
    {
        if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed ||
            Keyboard.GetState().IsKeyDown(Keys.Escape))
            Exit();

        // TODO: Add your update logic here
        star1.Update(gameTime);
        star2.Update(gameTime);

        base.Update(gameTime);
    }

    protected override void Draw(GameTime gameTime)
    {
        GraphicsDevice.Clear(Color.CornflowerBlue);

        // TODO: Add your drawing code here
        star1.Draw(_spriteBatch);
        star2.Draw(_spriteBatch);
        base.Draw(gameTime);
    }
}