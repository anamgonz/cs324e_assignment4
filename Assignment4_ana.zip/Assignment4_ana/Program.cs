﻿using var game = new Assignment4_ana.Game1();
game.Run();