﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Assignment4
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;

        private Plant seaweed1;
        private Plant seaweed2;

        private Texture2D backgroundTexture;

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;

            // Set window size for aquarium
            _graphics.PreferredBackBufferWidth = 800;
            _graphics.PreferredBackBufferHeight = 600;
        }

        protected override void Initialize()
        {
            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            backgroundTexture = new Texture2D(GraphicsDevice, 1, 1);
            backgroundTexture.SetData(new[] { new Color(20, 50, 100) }); 

            // INSTANCE 1: Tall, dark green seaweed on the left
            seaweed1 = new Plant(
                position: new Vector2(150, 550),           
                color: new Color(34, 139, 34),          
                segments: 8,                            
                height: 250,                         
                width: 15,                                
                speed: 0.8f,                          
                offset: 0f,                             
                graphicsDevice: GraphicsDevice
            );

            // INSTANCE 2: Shorter, lighter seaweed on the right
            seaweed2 = new Plant(
                position: new Vector2(650, 550),      
                color: new Color(60, 179, 113),        
                segments: 5,                                
                height: 150, 
                width: 13,                      
                speed: 1.3f,                         
                offset: 1.5f,                       
                graphicsDevice: GraphicsDevice
            );
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || 
                Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            // Update both seaweed instances
            seaweed1.Update(gameTime);
            seaweed2.Update(gameTime);

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            _spriteBatch.Begin();

            _spriteBatch.Draw(backgroundTexture, 
                new Rectangle(0, 0, _graphics.PreferredBackBufferWidth, _graphics.PreferredBackBufferHeight), 
                Color.White);

            seaweed1.Draw(_spriteBatch);
            seaweed2.Draw(_spriteBatch);

            // Your teammates will add their animated objects here
            // e.g., fish, bubbles, coral, etc.

            _spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
