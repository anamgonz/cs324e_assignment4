﻿using var game = new Assignment4.Game1();
game.Run();
