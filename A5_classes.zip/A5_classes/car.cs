﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

public class Car
{

    private const float APPROACH_START = 0f;
    private const float APPROACH_END   = 4f;
    private const float WAIT_END       = 7f;
    private const float DEPART_END     = 10f;

  
    private const float MAX_BRAKE_TILT =  3f;
    private const float MAX_ACCEL_TILT = -3f;

    private readonly Vector3 _startPos = new Vector3(-20f, 0f, 0f);
    private readonly Vector3 _stopPos  = new Vector3(  0f, 0f, 0f);
    private readonly Vector3 _exitPos  = new Vector3( 20f, 0f, 0f);

    private const float MODEL_SCALE = 1.0f;

    private float _elapsedTime;
    private float _tiltAngle;

    private Model _carModel;

    public Car() { }


    public void LoadContent(ContentManager content)
    {
        _carModel = content.Load<Model>("model/Car");
    }

    public void Update(float totalElapsedSeconds)
    {
        Update(totalElapsedSeconds, 1f / 60f);
    }

    public void Update(float totalElapsedSeconds, float deltaTime)
    {
        _elapsedTime = totalElapsedSeconds % DEPART_END;
        _tiltAngle   = GetCurrentTilt(_elapsedTime);
    }

    public void Draw(Matrix view, Matrix projection)
    {
        if (_carModel == null)
            return;


        Matrix tilt = Matrix.CreateRotationZ(MathHelper.ToRadians(_tiltAngle));
        
        Matrix bodyWorld =
            Matrix.CreateScale(MODEL_SCALE) *
            tilt *
            Matrix.CreateRotationY(MathHelper.ToRadians(90f)) *
            Matrix.CreateTranslation(GetCarPosition(_elapsedTime));

        foreach (ModelMesh mesh in _carModel.Meshes)
        {
            foreach (BasicEffect effect in mesh.Effects)
            {
                effect.EnableDefaultLighting();
                effect.World      = mesh.ParentBone.Transform * bodyWorld;
                effect.View       = view;
                effect.Projection = projection;
            }
            mesh.Draw();
        }
    }


    private Vector3 GetCarPosition(float t)
    {
        if (t < APPROACH_END)
        {
            float smooth = SmoothStep((t - APPROACH_START) / (APPROACH_END - APPROACH_START));
            return Vector3.Lerp(_startPos, _stopPos, smooth);
        }
        else if (t < WAIT_END)
        {
            return _stopPos;
        }
        else
        {
            float smooth = SmoothStep((t - WAIT_END) / (DEPART_END - WAIT_END));
            return Vector3.Lerp(_stopPos, _exitPos, smooth);
        }
    }

    private float GetCurrentTilt(float t)
    {
        if (t < APPROACH_END)
        {
            float raw = (t - APPROACH_START) / (APPROACH_END - APPROACH_START);
            return MathHelper.Lerp(0f, MAX_BRAKE_TILT, SmoothStep(raw));
        }
        else if (t < WAIT_END)
        {
            float raw = (t - APPROACH_END) / (WAIT_END - APPROACH_END);
            return MathHelper.Lerp(MAX_BRAKE_TILT, 0f, SmoothStep(raw));
        }
        else
        {
            float raw  = (t - WAIT_END) / (DEPART_END - WAIT_END);
            float ping = SmoothStep(raw < 0.5f ? raw * 2f : (1f - raw) * 2f);
            return MathHelper.Lerp(0f, MAX_ACCEL_TILT, ping);
        }
    }

    private static float SmoothStep(float t)
    {
        t = MathHelper.Clamp(t, 0f, 1f);
        return t * t * (3f - 2f * t);
    }

    public void Dispose() { }
}